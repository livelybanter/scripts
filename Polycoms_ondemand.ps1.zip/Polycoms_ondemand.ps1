﻿#Create DHCP Reservations for Polycoms
#Script writer - Michael Merrell
#Script Version - 1.0

#Get active scope

$getscope = Read-Host 'Enter Scope IP - 10.X.X.0'

#SetDHCPServer to Run against
$server = 'prd-windhcp03'

write-host "getting active phones on dhcp server $server"

#Get Active Scopes from DHCP Server
$scopes = Get-dhcpserverv4scope -ComputerName $server -ScopeId $getscope 
foreach ($scope in $scopes) {
#list full scope
$scope
#Get Active Polycom Devices with mac matching 00:04:f2, filter out .42 address and existing reservations
$polycoms = Get-DhcpServerv4Lease -computername $server -scopeid $scope.ScopeId -AllLeases | where {$_.addressState -notlike '*reservation'} | where {$_.IPAddress -notlike '*.42'} | Where {$_.clientid -like '00-04-f2*'}

#reserver each discovered phone
foreach ($phone in $polycoms) {
#exract ip from  each phone to find free ip. 
    $ipaddr = $phone.IPAddress.IPAddressToString
    $iproot = $ipaddr.split('.')      
    $startip = ($iproot[0]+"."+$iproot[1]+"."+$iproot[2]+"."+30)
    $endip = ($iproot[0]+"."+$iproot[1]+"."+$iproot[2]+"."+39)

#get free address between .30 and .39
$freeip = Get-DhcpServerv4FreeIPAddress -ComputerName $server -ScopeId $scope.ScopeId -StartAddress $startip -EndAddress $endip

#add reservation for each phone at new ip.
write-host "phone at $ipaddr will be moved to $freeip, Name:" $phone.HostName " Mac: " $phone.ClientId 
Add-DhcpServerv4Reservation -ComputerName $server -ScopeId $scope.ScopeID -IPAddress $freeip -ClientId $phone.ClientId -Name $phone.HostName -Verbose

}

}